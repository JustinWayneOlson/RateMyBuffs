# RateMyBuffs
A Chrome extension that makes choosing UCB classes easier by retrieve professor ratings from RateMyProfessors.com
