# RateMyBuffs
A Chrome extension that makes choosing UCB classes easier by retrieve professor ratings from cufcq.com  

Made by:  

Justin Olson @JustinWayneOlson  

Conner Simmering @simmeringc  

Samuel Volin @untra  

