RateMyBuffs - Justin Olson, Conner Simmering, Samuel Volin
